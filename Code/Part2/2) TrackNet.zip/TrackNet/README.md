# TrackNet
**Tracknet** is a deep learning network for tracking tiny and high-speed objects, especially balls from broadcast videos in which the ball images are small, blurry, and sometimes even invisible. 
**TrackNet** takes multiple consecutive frames (a film) as input, model will learn not only object tracking but also trajectory to enhance its capability of positioning and recognition. 
TrackNet generates **gaussian heat map** centered on ball to indicate position of the ball.

## Architecture
![](pics/tracknet_arch.jpg)

## Dataset
The dataset consists of video clips of 10 broadcast videos.

## Running the model
![](pics/video_infer.gif)
Run `python infer_on_video.py <args>` to launch inference on the video. 

## Reference
[https://arxiv.org/abs/1907.03698](https://arxiv.org/abs/1907.03698)

TrackNet: A Deep Learning Network for Tracking High-speed and Tiny Objects in Sports Applications
